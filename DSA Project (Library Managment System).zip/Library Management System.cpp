#include <iostream>
#include<cstring>
using namespace std;

// Book class
class Book {
public:
	string title;
	int id;
	string author;

	Book(string t, int i, string a) {
		title = t;
		id = i;
		author = a;
	}
};

// Node class for LinkedList
class Node {
public:
	Book* book;
	Node* next;

	Node(Book* b) {
		book = b;
		next = nullptr;
	}
};

// StackNode class for Stack
class StackNode {
public:
	Book* book;
	StackNode* next;

	StackNode(Book* b) {
		book = b;
		next = nullptr;
	}
};

// TreeNode class for BST
class TreeNode {
public:
	Book* book;
	TreeNode* left;
	TreeNode* right;

	TreeNode(Book* b, TreeNode* l, TreeNode* r) {
		book = b;
		left = l;
		right = r;
	}
};

// Library class
class Library {
private:
	Book** booksArray;
	Node* head;
	StackNode* top;
	TreeNode* root;
	int arraySize;
	int listSize;

public:
	Library(int size) {
		booksArray = new Book*[size];
		head = nullptr;
		top = nullptr;
		root = nullptr;
		arraySize = size;
		listSize = 0;
	}

	// ArrayList Operations
	void addBookArray(Book* book) {
		for (int i = 0; i < arraySize; i++) {
			if (booksArray[i] == nullptr) {
				booksArray[i] = book;
				cout << "Book added to ArrayList!" << endl;
				return;
			}
		}
		cout << "ArrayList is full! Cannot add book." << endl;
	}

	void displayBooksArray() {
		for (int i = 0; i < arraySize; i++) {
			if (booksArray[i] != nullptr) {
				cout << "Title: " << booksArray[i]->title << ", ID: " << booksArray[i]->id
					<< ", Author: " << booksArray[i]->author << endl;
			}
		}
	}

	void searchBookArray(int id) {
		for (int i = 0; i < arraySize; i++) {
			if (booksArray[i] != nullptr && booksArray[i]->id == id) {
				cout << "Book found in ArrayList!" << endl;
				return;
			}
		}
		cout << "Book not found in ArrayList!" << endl;
	}

	void deleteBookArray(int id) {
		for (int i = 0; i < arraySize; i++) {
			if (booksArray[i] != nullptr && booksArray[i]->id == id) {
				delete booksArray[i];
				booksArray[i] = nullptr;
				cout << "Book deleted from ArrayList!" << endl;
				return;
			}
		}
		cout << "Book not found in ArrayList!" << endl;
	}

	// LinkedList Operations
	void addBookList(Book* book) {
		Node* newNode = new Node(book);
		if (head == nullptr) {
			head = newNode;
		}
		else {
			Node* current = head;
			while (current->next != nullptr) {
				current = current->next;
			}
			current->next = newNode;
		}
		listSize++;
		cout << "Book added to LinkedList!" << endl;
	}

	void displayBooksList() {
		Node* current = head;
		while (current != nullptr) {
			cout << "Title: " << current->book->title << ", ID: " << current->book->id
				<< ", Author: " << current->book->author << endl;
			current = current->next;
		}
	}

	void searchBookList(int id) {
		Node* current = head;
		while (current != nullptr) {
			if (current->book->id == id) {
				cout << "Book found in LinkedList!" << endl;
				return;
			}
			current = current->next;
		}
		cout << "Book not found in LinkedList!" << endl;
	}

	void deleteBookList(int id) {
		if (head == nullptr) {
			cout << "Book not found in LinkedList!" << endl;
			return;
		}

		if (head->book->id == id) {
			Node* temp = head;
			head = head->next;
			delete temp;
			listSize--;
			cout << "Book deleted from LinkedList!" << endl;
			return;
		}

		Node* prev = head;
		Node* current = head->next;
		while (current != nullptr) {
			if (current->book->id == id) {
				prev->next = current->next;
				delete current;
				listSize--;
				cout << "Book deleted from LinkedList!" << endl;
				return;
			}
			prev = current;
			current = current->next;
		}

		cout << "Book not found in LinkedList!" << endl;
	}

	// Stack Operations
	void pushStack(Book* book) {
		StackNode* newNode = new StackNode(book);
		if (top == nullptr) {
			top = newNode;
		}
		else {
			newNode->next = top;
			top = newNode;
		}
		cout << "Book pushed to Stack!" << endl;
	}

	void displayStack() {
		StackNode* current = top;
		while (current != nullptr) {
			cout << "Title: " << current->book->title << ", ID: " << current->book->id
				<< ", Author: " << current->book->author << endl;
			current = current->next;
		}
	}

	void popStack() {
		if (top == nullptr) {
			cout << "Stack is empty!" << endl;
			return;
		}

		StackNode* temp = top;
		top = top->next;
		delete temp;
		cout << "Book popped from Stack!" << endl;
	}

	void deleteBookStack(int id) {
		if (top == nullptr) {
			cout << "Book not found in Stack!" << endl;
			return;
		}

		if (top->book->id == id) {
			StackNode* temp = top;
			top = top->next;
			delete temp;
			cout << "Book deleted from Stack!" << endl;
			return;
		}

		StackNode* prev = top;
		StackNode* current = top->next;
		while (current != nullptr) {
			if (current->book->id == id) {
				prev->next = current->next;
				delete current;
				cout << "Book deleted from Stack!" << endl;
				return;
			}
			prev = current;
			current = current->next;
		}

		cout << "Book not found in Stack!" << endl;
	}

	// BST Operations
	void insertBookBST(Book* book) {
		root = insertNode(root, book);
		cout << "Book inserted into BST!" << endl;
	}

	TreeNode* insertNode(TreeNode* root, Book* book) {
		if (root == nullptr) {
			return new TreeNode(book, nullptr, nullptr);
		}

		if (book->id < root->book->id) {
			root->left = insertNode(root->left, book);
		}
		else {
			root->right = insertNode(root->right, book);
		}

		return root;
	}

	void displayBooksBST() {
		inorderTraversal(root);
	}

	void inorderTraversal(TreeNode* root) {
		if (root != nullptr) {
			inorderTraversal(root->left);
			cout << "Title: " << root->book->title << ", ID: " << root->book->id
				<< ", Author: " << root->book->author << endl;
			inorderTraversal(root->right);
		}
	}

	void searchBookBST(int id) {
		if (searchNode(root, id)) {
			cout << "Book found in BST!" << endl;
		}
		else {
			cout << "Book not found in BST!" << endl;
		}
	}

	bool searchNode(TreeNode* root, int id) {
		if (root == nullptr || root->book->id == id) {
			return (root != nullptr);
		}

		if (id < root->book->id) {
			return searchNode(root->left, id);
		}
		else {
			return searchNode(root->right, id);
		}
	}

	void deleteBookBST(int id) {
		root = deleteNode(root, id);
	}

	TreeNode* deleteNode(TreeNode* root, int id) {
		if (root == nullptr) {
			cout << "Book not found in BST!" << endl;
			return root;
		}

		if (id < root->book->id) {
			root->left = deleteNode(root->left, id);
		}
		else if (id > root->book->id) {
			root->right = deleteNode(root->right, id);
		}
		else {
			if (root->left == nullptr) {
				TreeNode* temp = root->right;
				delete root;
				cout << "Book deleted from BST!" << endl;
				return temp;
			}
			else if (root->right == nullptr) {
				TreeNode* temp = root->left;
				delete root;
				cout << "Book deleted from BST!" << endl;
				return temp;
			}

			TreeNode* minNode = findMinNode(root->right);
			root->book = minNode->book;
			root->right = deleteNode(root->right, minNode->book->id);
		}

		return root;
	}

	TreeNode* findMinNode(TreeNode* node) {
		while (node->left != nullptr) {
			node = node->left;
		}
		return node;
	}
};

int main() {
	int size;
	cout << "Enter the size of the library: ";
	cin >> size;
	Library library(size);

	int choice;
	while (true) {
		cout << "\n--- Library Management System ---" << endl;
		cout << "1. Add book to ArrayList" << endl;
		cout << "2. Display books in ArrayList" << endl;
		cout << "3. Search book in ArrayList" << endl;
		cout << "4. Delete book from ArrayList" << endl;
		cout << "5. Add book to LinkedList" << endl;
		cout << "6. Display books in LinkedList" << endl;
		cout << "7. Search book in LinkedList" << endl;
		cout << "8. Delete book from LinkedList" << endl;
		cout << "9. Push book to Stack" << endl;
		cout << "10. Display books in Stack" << endl;
		cout << "11. Pop book from Stack" << endl;
		cout << "12. Delete book from Stack" << endl;
		cout << "13. Insert book into BST" << endl;
		cout << "14. Display books in BST" << endl;
		cout << "15. Search book in BST" << endl;
		cout << "16. Delete book from BST" << endl;
		cout << "0. Exit" << endl;

		cout << "Enter your choice: ";
		cin >> choice;

		switch (choice) {
		case 0:
			cout << "Exiting program..." << endl;
			return 0;

		case 1: {
					string title, author;
					int id;
					cout << "Enter book title: ";
					cin.ignore();
					getline(cin, title);
					cout << "Enter book ID: ";
					cin >> id;
					cout << "Enter book author: ";
					cin.ignore();
					getline(cin, author);
					Book* book = new Book(title, id, author);
					library.addBookArray(book);
					break;
		}

		case 2:
			cout << "\n--- Books in ArrayList ---" << endl;
			library.displayBooksArray();
			break;

		case 3: {
					int id;
					cout << "Enter book ID to search: ";
					cin >> id;
					library.searchBookArray(id);
					break;
		}

		case 4: {
					int id;
					cout << "Enter book ID to delete: ";
					cin >> id;
					library.deleteBookArray(id);
					break;
		}

		case 5: {
					string title, author;
					int id;
					cout << "Enter book title: ";
					cin.ignore();
					getline(cin, title);
					cout << "Enter book ID: ";
					cin >> id;
					cout << "Enter book author: ";
					cin.ignore();
					getline(cin, author);
					Book* book = new Book(title, id, author);
					library.addBookList(book);
					break;
		}

		case 6:
			cout << "\n--- Books in LinkedList ---" << endl;
			library.displayBooksList();
			break;

		case 7: {
					int id;
					cout << "Enter book ID to search: ";
					cin >> id;
					library.searchBookList(id);
					break;
		}

		case 8: {
					int id;
					cout << "Enter book ID to delete: ";
					cin >> id;
					library.deleteBookList(id);
					break;
		}

		case 9: {
					string title, author;
					int id;
					cout << "Enter book title: ";
					cin.ignore();
					getline(cin, title);
					cout << "Enter book ID: ";
					cin >> id;
					cout << "Enter book author: ";
					cin.ignore();
					getline(cin, author);
					Book* book = new Book(title, id, author);
					library.pushStack(book);
					break;
		}

		case 10:
			cout << "\n--- Books in Stack ---" << endl;
			library.displayStack();
			break;

		case 11:
			library.popStack();
			break;

		case 12: {
					 int id;
					 cout << "Enter book ID to delete: ";
					 cin >> id;
					 library.deleteBookStack(id);
					 break;
		}

		case 13: {
					 string title, author;
					 int id;
					 cout << "Enter book title: ";
					 cin.ignore();
					 getline(cin, title);
					 cout << "Enter book ID: ";
					 cin >> id;
					 cout << "Enter book author: ";
					 cin.ignore();
					 getline(cin, author);
					 Book* book = new Book(title, id, author);
					 library.insertBookBST(book);
					 break;
		}

		case 14:
			cout << "\n--- Books in BST ---" << endl;
			library.displayBooksBST();
			break;

		case 15: {
					 int id;
					 cout << "Enter book ID to search: ";
					 cin >> id;
					 library.searchBookBST(id);
					 break;
		}

		case 16: {
					 int id;
					 cout << "Enter book ID to delete: ";
					 cin >> id;
					 library.deleteBookBST(id);
					 break;
		}

		default:
			cout << "Invalid choice! Please try again." << endl;
		}
	}
	system("pause");

	return 0;
}
